﻿
namespace Pmatrizes
{
    partial class NomePessoas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnpessoas = new System.Windows.Forms.Button();
            this.listNomes = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnpessoas
            // 
            this.btnpessoas.Location = new System.Drawing.Point(97, 201);
            this.btnpessoas.Name = "btnpessoas";
            this.btnpessoas.Size = new System.Drawing.Size(178, 132);
            this.btnpessoas.TabIndex = 0;
            this.btnpessoas.Text = "Receber Nomes";
            this.btnpessoas.UseVisualStyleBackColor = true;
            this.btnpessoas.Click += new System.EventHandler(this.btnpessoas_Click);
            // 
            // listNomes
            // 
            this.listNomes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listNomes.Enabled = false;
            this.listNomes.FormattingEnabled = true;
            this.listNomes.ItemHeight = 16;
            this.listNomes.Location = new System.Drawing.Point(343, 26);
            this.listNomes.Name = "listNomes";
            this.listNomes.Size = new System.Drawing.Size(520, 468);
            this.listNomes.TabIndex = 10;
            // 
            // NomePessoas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(890, 521);
            this.Controls.Add(this.listNomes);
            this.Controls.Add(this.btnpessoas);
            this.Name = "NomePessoas";
            this.Text = "NomePessoas";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnpessoas;
        private System.Windows.Forms.ListBox listNomes;
    }
}