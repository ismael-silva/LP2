namespace pImc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            double peso;
            double altura;
            double resultado;

            if (Double.TryParse(txtPeso.Text, out peso) &&
                Double.TryParse(txtAltura.Text, out altura))
            {

                if ((peso <= 0) || (altura <= 0))
                { 
                    MessageBox.Show("Valores devem ser maior que zero");
                }
                else
                {
                    resultado = peso / (altura * altura);

                    resultado = Math.Round(resultado, 1); //arrendonda

                    txtResultado.Text = resultado.ToString();

                    if (resultado < 18.5)
                    {
                        MessageBox.Show("Magreza");
                    }

                    else if (resultado < 24.9)
                    {
                        MessageBox.Show("Normal");
                    }
                    else if (resultado < 29.9)
                    {
                        MessageBox.Show("Sobre peso");
                    }
                    else if (resultado < 39.9)
                    {
                        MessageBox.Show("Obsidade");
                    }
                    else       
                    {
                        MessageBox.Show("Obsidade grave");
                    }

                }
            }
            else
            {
                MessageBox.Show("Valores Inv�lidos.");
            }

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtPeso.Text = "";
            txtResultado.Text = "";
        }
    }
}

