﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void btnInstanciarHorista_Click(object sender, EventArgs e)
        {
           
            Horista objHorista = new Horista();

            // set - atribui valores para o objeto
            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalarioHora.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtNumeroHoras.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntradaEmpresa.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtDiasFaltas.Text);

            if (rbtnSim.Checked)
            {
                objHorista.HomeOffice = 'S';
            }
            else
                objHorista.HomeOffice = 'N';

            //get - imprime os valores do objeto
            //get
            MessageBox.Show("Matrícula: " + objHorista.Matricula + "\n" + "Nome: " + objHorista.NomeEmpregado + "\n" +
                "Data Entrada: " + objHorista.DataEntradaEmpresa.ToShortDateString() + "\n" +
                "Salário Bruto: " + objHorista.SalarioBruto().ToString("n2") + "\n" +
                "Tempo Empresa (Dias): " + objHorista.TempoTrabalho() +
                "\n" + objHorista.VerificaHome()); 
        }
    }
}
