﻿namespace PClasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInstanciarHorista = new System.Windows.Forms.Button();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioHora = new System.Windows.Forms.Label();
            this.lblNumeroHoras = new System.Windows.Forms.Label();
            this.lblDataEntradaEmpresa = new System.Windows.Forms.Label();
            this.lblDiasFaltas = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalarioHora = new System.Windows.Forms.TextBox();
            this.txtNumeroHoras = new System.Windows.Forms.TextBox();
            this.txtDataEntradaEmpresa = new System.Windows.Forms.TextBox();
            this.txtDiasFaltas = new System.Windows.Forms.TextBox();
            this.gbHomeOffice = new System.Windows.Forms.GroupBox();
            this.rbtnSim = new System.Windows.Forms.RadioButton();
            this.rbtnNao = new System.Windows.Forms.RadioButton();
            this.gbHomeOffice.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnInstanciarHorista
            // 
            this.btnInstanciarHorista.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInstanciarHorista.Location = new System.Drawing.Point(178, 410);
            this.btnInstanciarHorista.Name = "btnInstanciarHorista";
            this.btnInstanciarHorista.Size = new System.Drawing.Size(407, 43);
            this.btnInstanciarHorista.TabIndex = 0;
            this.btnInstanciarHorista.Text = "Intanciar Horista";
            this.btnInstanciarHorista.UseVisualStyleBackColor = true;
            this.btnInstanciarHorista.Click += new System.EventHandler(this.btnInstanciarHorista_Click);
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatricula.Location = new System.Drawing.Point(31, 55);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(73, 20);
            this.lblMatricula.TabIndex = 1;
            this.lblMatricula.Text = "Matrícula";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMatricula.Location = new System.Drawing.Point(229, 55);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(73, 26);
            this.txtMatricula.TabIndex = 2;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(31, 121);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(51, 20);
            this.lblNome.TabIndex = 3;
            this.lblNome.Text = "Nome";
            // 
            // lblSalarioHora
            // 
            this.lblSalarioHora.AutoSize = true;
            this.lblSalarioHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioHora.Location = new System.Drawing.Point(31, 182);
            this.lblSalarioHora.Name = "lblSalarioHora";
            this.lblSalarioHora.Size = new System.Drawing.Size(97, 20);
            this.lblSalarioHora.TabIndex = 4;
            this.lblSalarioHora.Text = "Salário Hora";
            // 
            // lblNumeroHoras
            // 
            this.lblNumeroHoras.AutoSize = true;
            this.lblNumeroHoras.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeroHoras.Location = new System.Drawing.Point(31, 235);
            this.lblNumeroHoras.Name = "lblNumeroHoras";
            this.lblNumeroHoras.Size = new System.Drawing.Size(112, 20);
            this.lblNumeroHoras.TabIndex = 5;
            this.lblNumeroHoras.Text = "Número Horas";
            // 
            // lblDataEntradaEmpresa
            // 
            this.lblDataEntradaEmpresa.AutoSize = true;
            this.lblDataEntradaEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataEntradaEmpresa.Location = new System.Drawing.Point(31, 285);
            this.lblDataEntradaEmpresa.Name = "lblDataEntradaEmpresa";
            this.lblDataEntradaEmpresa.Size = new System.Drawing.Size(195, 20);
            this.lblDataEntradaEmpresa.TabIndex = 6;
            this.lblDataEntradaEmpresa.Text = "Data Entrada na Empresa";
            // 
            // lblDiasFaltas
            // 
            this.lblDiasFaltas.AutoSize = true;
            this.lblDiasFaltas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiasFaltas.Location = new System.Drawing.Point(31, 333);
            this.lblDiasFaltas.Name = "lblDiasFaltas";
            this.lblDiasFaltas.Size = new System.Drawing.Size(111, 20);
            this.lblDiasFaltas.TabIndex = 7;
            this.lblDiasFaltas.Text = "Dias de Faltas";
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(229, 121);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(204, 26);
            this.txtNome.TabIndex = 8;
            // 
            // txtSalarioHora
            // 
            this.txtSalarioHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalarioHora.Location = new System.Drawing.Point(229, 176);
            this.txtSalarioHora.Name = "txtSalarioHora";
            this.txtSalarioHora.Size = new System.Drawing.Size(85, 26);
            this.txtSalarioHora.TabIndex = 9;
            // 
            // txtNumeroHoras
            // 
            this.txtNumeroHoras.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumeroHoras.Location = new System.Drawing.Point(229, 229);
            this.txtNumeroHoras.Name = "txtNumeroHoras";
            this.txtNumeroHoras.Size = new System.Drawing.Size(73, 26);
            this.txtNumeroHoras.TabIndex = 10;
            // 
            // txtDataEntradaEmpresa
            // 
            this.txtDataEntradaEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDataEntradaEmpresa.Location = new System.Drawing.Point(229, 279);
            this.txtDataEntradaEmpresa.Name = "txtDataEntradaEmpresa";
            this.txtDataEntradaEmpresa.Size = new System.Drawing.Size(140, 26);
            this.txtDataEntradaEmpresa.TabIndex = 11;
            // 
            // txtDiasFaltas
            // 
            this.txtDiasFaltas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiasFaltas.Location = new System.Drawing.Point(229, 333);
            this.txtDiasFaltas.Name = "txtDiasFaltas";
            this.txtDiasFaltas.Size = new System.Drawing.Size(100, 26);
            this.txtDiasFaltas.TabIndex = 12;
            // 
            // gbHomeOffice
            // 
            this.gbHomeOffice.Controls.Add(this.rbtnNao);
            this.gbHomeOffice.Controls.Add(this.rbtnSim);
            this.gbHomeOffice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbHomeOffice.Location = new System.Drawing.Point(596, 148);
            this.gbHomeOffice.Name = "gbHomeOffice";
            this.gbHomeOffice.Size = new System.Drawing.Size(209, 106);
            this.gbHomeOffice.TabIndex = 13;
            this.gbHomeOffice.TabStop = false;
            this.gbHomeOffice.Text = "Trabalha em Home office";
            // 
            // rbtnSim
            // 
            this.rbtnSim.AutoSize = true;
            this.rbtnSim.Location = new System.Drawing.Point(7, 30);
            this.rbtnSim.Name = "rbtnSim";
            this.rbtnSim.Size = new System.Drawing.Size(49, 20);
            this.rbtnSim.TabIndex = 0;
            this.rbtnSim.TabStop = true;
            this.rbtnSim.Text = "Sim";
            this.rbtnSim.UseVisualStyleBackColor = true;
            // 
            // rbtnNao
            // 
            this.rbtnNao.AutoSize = true;
            this.rbtnNao.Location = new System.Drawing.Point(7, 64);
            this.rbtnNao.Name = "rbtnNao";
            this.rbtnNao.Size = new System.Drawing.Size(52, 20);
            this.rbtnNao.TabIndex = 1;
            this.rbtnNao.TabStop = true;
            this.rbtnNao.Text = "Não";
            this.rbtnNao.UseVisualStyleBackColor = true;
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(815, 465);
            this.Controls.Add(this.gbHomeOffice);
            this.Controls.Add(this.txtDiasFaltas);
            this.Controls.Add(this.txtDataEntradaEmpresa);
            this.Controls.Add(this.txtNumeroHoras);
            this.Controls.Add(this.txtSalarioHora);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblDiasFaltas);
            this.Controls.Add(this.lblDataEntradaEmpresa);
            this.Controls.Add(this.lblNumeroHoras);
            this.Controls.Add(this.lblSalarioHora);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.btnInstanciarHorista);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.gbHomeOffice.ResumeLayout(false);
            this.gbHomeOffice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInstanciarHorista;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioHora;
        private System.Windows.Forms.Label lblNumeroHoras;
        private System.Windows.Forms.Label lblDataEntradaEmpresa;
        private System.Windows.Forms.Label lblDiasFaltas;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalarioHora;
        private System.Windows.Forms.TextBox txtNumeroHoras;
        private System.Windows.Forms.TextBox txtDataEntradaEmpresa;
        private System.Windows.Forms.TextBox txtDiasFaltas;
        private System.Windows.Forms.GroupBox gbHomeOffice;
        private System.Windows.Forms.RadioButton rbtnNao;
        private System.Windows.Forms.RadioButton rbtnSim;
    }
}