﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class NomePessoas : Form
    {
        public NomePessoas()
        {
            InitializeComponent();
        }

        private void btnpessoas_Click(object sender, EventArgs e)
        {
            double valid = 0;
            string RaEsc;
            int Ra;

            RaEsc = Interaction.InputBox("Digite o seu RA ", "Entrada de dados");

            if (double.TryParse(RaEsc, out valid))
            {
                RaEsc = RaEsc.Substring(RaEsc.Length - 1, 1);
            }
            else
            {
                MessageBox.Show("RA inválido!");
            }
            int.TryParse(RaEsc, out Ra);

            if (Ra == 0)
            {
                Ra = 10;
            }
            string[] nomes = new string[Ra];
            string[] auxiliar = new string[Ra];
            int[] compr = new int[Ra];

            for (var i = 0; i < Ra; i++)
            {
                nomes[i] = Interaction.InputBox("Digite o nome completo " + (i + 1), "Entrada de dados");
                if (double.TryParse(nomes[i], out valid))
                {
                    MessageBox.Show("Somente Letras!");
                    i--;
                }
                else
                {
                    auxiliar[i] = nomes[i].Replace(" ", "");
                    compr[i] = auxiliar[i].Length;
                    listNomes.Items.Add("O nome: " + nomes[i] + " tem " + compr[i] + " caracteres");
                }
            }
        }
            
        
    }
}
