namespace pTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double A, B, C;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtResultado.Text = "";
            txtA.Text = "";
            txtB.Text = "";
            txtC.Text = "";
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnExecultar_Click(object sender, EventArgs e)
        {
            // Testando valores.
            if (!double.TryParse(txtA.Text, out A) ||
                !double.TryParse(txtB.Text, out B) ||
                !double.TryParse(txtC.Text, out C))
            {
                MessageBox.Show("Verifique se digitou Numeros");
            }
            else
            {
                // Verificando as condi��es necess�ria para um triangulo
                if (A<(B+C) && A>Math.Abs(B-C) && B < (A+C) && B > Math.Abs(A-C) && C > Math.Abs(A-B))
                {
                    if (A == B && B == C)
                    {
                        txtResultado.Text = "Triangulo equilatero.";
                    }
                    else if (A == B || A == C || C == B)
                    {
                        txtResultado.Text = "Triangulo is�sceles.";
                    }
                    else
                    {
                        txtResultado.Text = "Triangulo escaleno.";
                    }
                }
            }
        }


    }
}