namespace PCalc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double numero1, numero2;
        double volume;
        private void btnSoma_Click(object sender, EventArgs e)
        {
            

            if (Double.TryParse(txtNumeroUm.Text, out numero1) &&
                Double.TryParse(txtNumeroDois.Text, out numero2))
            {
                    
                    volume = numero1 + numero2;
                txtResultado.Text = volume.ToString(); 
            }
            else
            {
                MessageBox.Show("Valores inv�lidos");
                txtNumeroUm.Focus();
            }
        }

        private void btnSubitracao_Click(object sender, EventArgs e)
        {
           

            if (Double.TryParse(txtNumeroUm.Text, out numero1) &&
                Double.TryParse(txtNumeroDois.Text, out numero2))
            {

                volume = numero1 - numero2;
                txtResultado.Text = volume.ToString();
            }
            else
            {
                MessageBox.Show("Valores inv�lidos");
                txtNumeroUm.Focus();
            }
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
           

            if (Double.TryParse(txtNumeroUm.Text, out numero1) &&
                Double.TryParse(txtNumeroDois.Text, out numero2))
            {

                volume = numero1 * numero2;
                txtResultado.Text = volume.ToString();
            }
            else
            {
                MessageBox.Show("Valores inv�lidos");
                txtNumeroUm.Focus();
            }
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
           

            if (Double.TryParse(txtNumeroUm.Text, out numero1) &&
                Double.TryParse(txtNumeroDois.Text, out numero2))
            {
                if (numero2 == 0) 
                {
                    MessageBox.Show("N�o pode dividir por Zero");
                    txtNumeroDois.Focus();
                }
                else if (numero1 == 0)
                {
                    volume = 0;
                    txtResultado.Text = volume.ToString();
                }
                    volume = numero1 / numero2;
                txtResultado.Text = volume.ToString();
            }
            else
            {
                MessageBox.Show("Valores inv�lidos");
                txtNumeroUm.Focus();
            }

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumeroUm.Text = ("");
            txtNumeroDois.Text = ("");
            txtResultado.Text = ("");
        }
    }
}
