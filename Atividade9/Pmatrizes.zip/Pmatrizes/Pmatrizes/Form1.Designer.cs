﻿namespace Pmatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnLer1 = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnPessoas = new System.Windows.Forms.Button();
            this.btnArray = new System.Windows.Forms.Button();
            this.btnVariavel = new System.Windows.Forms.Button();
            this.btnLer2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnLer1
            // 
            this.btnLer1.BackColor = System.Drawing.Color.Transparent;
            this.btnLer1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLer1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnLer1.Location = new System.Drawing.Point(139, 163);
            this.btnLer1.Margin = new System.Windows.Forms.Padding(4);
            this.btnLer1.Name = "btnLer1";
            this.btnLer1.Size = new System.Drawing.Size(208, 114);
            this.btnLer1.TabIndex = 0;
            this.btnLer1.Text = "Ler 20 números e inverter";
            this.btnLer1.UseVisualStyleBackColor = false;
            this.btnLer1.Click += new System.EventHandler(this.btnLer1_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.BackColor = System.Drawing.Color.Transparent;
            this.btnMedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMedia.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnMedia.Location = new System.Drawing.Point(370, 297);
            this.btnMedia.Margin = new System.Windows.Forms.Padding(4);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(208, 114);
            this.btnMedia.TabIndex = 1;
            this.btnMedia.Text = "Media Alunos";
            this.btnMedia.UseVisualStyleBackColor = false;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnPessoas
            // 
            this.btnPessoas.BackColor = System.Drawing.Color.Transparent;
            this.btnPessoas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPessoas.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnPessoas.Location = new System.Drawing.Point(602, 297);
            this.btnPessoas.Margin = new System.Windows.Forms.Padding(4);
            this.btnPessoas.Name = "btnPessoas";
            this.btnPessoas.Size = new System.Drawing.Size(208, 114);
            this.btnPessoas.TabIndex = 2;
            this.btnPessoas.Text = "Nomes Pessoas";
            this.btnPessoas.UseVisualStyleBackColor = false;
            this.btnPessoas.Click += new System.EventHandler(this.btnPessoas_Click);
            // 
            // btnArray
            // 
            this.btnArray.BackColor = System.Drawing.Color.Transparent;
            this.btnArray.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArray.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnArray.Location = new System.Drawing.Point(139, 297);
            this.btnArray.Margin = new System.Windows.Forms.Padding(4);
            this.btnArray.Name = "btnArray";
            this.btnArray.Size = new System.Drawing.Size(208, 114);
            this.btnArray.TabIndex = 3;
            this.btnArray.Text = "ArrayList";
            this.btnArray.UseVisualStyleBackColor = false;
            this.btnArray.Click += new System.EventHandler(this.btnArray_Click);
            // 
            // btnVariavel
            // 
            this.btnVariavel.BackColor = System.Drawing.Color.Transparent;
            this.btnVariavel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVariavel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnVariavel.Location = new System.Drawing.Point(602, 163);
            this.btnVariavel.Margin = new System.Windows.Forms.Padding(4);
            this.btnVariavel.Name = "btnVariavel";
            this.btnVariavel.Size = new System.Drawing.Size(208, 114);
            this.btnVariavel.TabIndex = 4;
            this.btnVariavel.Text = "Variável total";
            this.btnVariavel.UseVisualStyleBackColor = false;
            this.btnVariavel.Click += new System.EventHandler(this.btnVariavel_Click);
            // 
            // btnLer2
            // 
            this.btnLer2.BackColor = System.Drawing.Color.Transparent;
            this.btnLer2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLer2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnLer2.Location = new System.Drawing.Point(370, 163);
            this.btnLer2.Margin = new System.Windows.Forms.Padding(4);
            this.btnLer2.Name = "btnLer2";
            this.btnLer2.Size = new System.Drawing.Size(208, 114);
            this.btnLer2.TabIndex = 5;
            this.btnLer2.Text = "Ler Qtd. e Preço de Mercadorias";
            this.btnLer2.UseVisualStyleBackColor = false;
            this.btnLer2.Click += new System.EventHandler(this.btnLer2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Franklin Gothic Demi", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(221, 59);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(495, 54);
            this.label1.TabIndex = 6;
            this.label1.Text = "Atividade 9 - PMatrizes";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(957, 672);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnLer2);
            this.Controls.Add(this.btnVariavel);
            this.Controls.Add(this.btnArray);
            this.Controls.Add(this.btnPessoas);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnLer1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLer1;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnPessoas;
        private System.Windows.Forms.Button btnArray;
        private System.Windows.Forms.Button btnVariavel;
        private System.Windows.Forms.Button btnLer2;
        private System.Windows.Forms.Label label1;
    }
}

