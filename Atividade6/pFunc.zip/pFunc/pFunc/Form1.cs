namespace pFunc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void brnVeriDesc_Click(object sender, EventArgs e)
        {
            double descontoinss = 0;
            double descontoirpf = 0;
            double salarioBruto = 0;
            double salariofamilia = 0;
            double salarioLiquido = 0;
            double numerofilhos = 0;

            if (txtNomeFunc.Text == String.Empty)//Ele ir� testar se estiver Vazio
            {
                MessageBox.Show("O nome do Funcion�rio" + "\n N�o pode ser vaxio!");
            }
            else
            {
                if (msbxSalBruto.Text.Replace(",", "").Trim() == "")
                    MessageBox.Show("Valor do Sal�rio Invalido ou Igual a 0");

                if (!double.TryParse(msbxSalBruto.Text, out salarioBruto) || !double.TryParse(cbxFilho.Text, out numerofilhos))
                {
                    MessageBox.Show("Sal�rio Bruto e N�mero de filhos devem ser N�meros");
                }
                else
                {
                    if (salarioBruto <= 0)
                        MessageBox.Show("Sal�rio devem ser maior que 0");
                    else
                    {
                        //Calculo de INSS
                        if (salarioBruto <= 800.47)
                        {
                            msbxAliInss.Text = ("7,65%");
                            descontoinss = 0.0765 * salarioBruto;
                        }
                        else if (salarioBruto <= 1050)
                        {
                            msbxAliInss.Text = ("8,65%");
                            descontoinss = 0.0865 * salarioBruto;
                        }
                        else if (salarioBruto <= 1400.77)
                        {
                            msbxAliInss.Text = ("9%");
                            descontoinss = 0.09 * salarioBruto;
                        }
                        else if (salarioBruto <= 2801.56)
                        {
                            msbxAliInss.Text = ("11%");
                            descontoinss = 0.11 * salarioBruto;
                        }
                        else
                        {
                            msbxAliInss.Text = ("Teto");
                            descontoinss = 308.17;
                        }

                        msbxdescInss.Text = descontoinss.ToString("N2");

                        //Calculo de IRPF
                        if (salarioBruto <= 1257.12)
                        {
                            msbxAliIrpf.Text = ("0");
                        }

                        else if (salarioBruto <= 2512.08)
                        {
                            msbxAliIrpf.Text = ("15%");
                            descontoirpf = 0.15 * salarioBruto;
                        }

                        else
                        {
                            msbxAliIrpf.Text = ("27.5%");
                            descontoirpf = 0.275 * salarioBruto;
                        }
                        msbxDescIrpf.Text = descontoirpf.ToString("N2");

                        if (salarioBruto <= 435.52)
                            salariofamilia = 0.2233 * numerofilhos;

                        else if (salarioBruto <= 654.61)
                            salariofamilia = 0.1574 * numerofilhos;
                        else
                            salariofamilia = 0;

                        msbxsalFami.Text = salariofamilia.ToString("N2");

                        salarioLiquido = salarioBruto - descontoinss - descontoirpf + salariofamilia;

                        msbxSalLiqui.Text = salarioLiquido.ToString("N2");

                        lblMostra.Text = "Os descontos do Sal�rio " + (rbnFeminino.Checked ? "da Sra." : "do Sr.") + txtNomeFunc.Text +
                        " que � " + (cbxCasado.Checked ? "Casado(a)" : "Solteiro(a)") + "  e que tem " +
                        Convert.ToString(numerofilhos) + " filho(s) s�o:";   

                    }
                }
            }
        }

        private void msbxsalFami_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}