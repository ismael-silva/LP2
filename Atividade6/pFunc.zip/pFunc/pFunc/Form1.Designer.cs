﻿namespace pFunc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.brnVeriDesc = new System.Windows.Forms.Button();
            this.lblNomeFunc = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblNumFilho = new System.Windows.Forms.Label();
            this.lblDescIrpf = new System.Windows.Forms.Label();
            this.lblDescInss = new System.Windows.Forms.Label();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblAliIfpf = new System.Windows.Forms.Label();
            this.lblAliInss = new System.Windows.Forms.Label();
            this.lblMostra = new System.Windows.Forms.Label();
            this.cbxCasado = new System.Windows.Forms.CheckBox();
            this.msbxSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.txtNomeFunc = new System.Windows.Forms.TextBox();
            this.msbxAliInss = new System.Windows.Forms.MaskedTextBox();
            this.msbxAliIrpf = new System.Windows.Forms.MaskedTextBox();
            this.msbxsalFami = new System.Windows.Forms.MaskedTextBox();
            this.msbxSalLiqui = new System.Windows.Forms.MaskedTextBox();
            this.msbxDescIrpf = new System.Windows.Forms.MaskedTextBox();
            this.cbxFilho = new System.Windows.Forms.ComboBox();
            this.msbxdescInss = new System.Windows.Forms.MaskedTextBox();
            this.rbnFeminino = new System.Windows.Forms.RadioButton();
            this.gbxSexo = new System.Windows.Forms.GroupBox();
            this.rbnMasculino = new System.Windows.Forms.RadioButton();
            this.gbxSexo.SuspendLayout();
            this.SuspendLayout();
            // 
            // brnVeriDesc
            // 
            this.brnVeriDesc.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.brnVeriDesc.Location = new System.Drawing.Point(245, 287);
            this.brnVeriDesc.Name = "brnVeriDesc";
            this.brnVeriDesc.Size = new System.Drawing.Size(262, 39);
            this.brnVeriDesc.TabIndex = 0;
            this.brnVeriDesc.Text = "Verifica Desconto";
            this.brnVeriDesc.UseVisualStyleBackColor = true;
            this.brnVeriDesc.Click += new System.EventHandler(this.brnVeriDesc_Click);
            // 
            // lblNomeFunc
            // 
            this.lblNomeFunc.AutoSize = true;
            this.lblNomeFunc.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblNomeFunc.Location = new System.Drawing.Point(36, 46);
            this.lblNomeFunc.Name = "lblNomeFunc";
            this.lblNomeFunc.Size = new System.Drawing.Size(174, 28);
            this.lblNomeFunc.TabIndex = 1;
            this.lblNomeFunc.Text = "Nome Funcionário";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSalBruto.Location = new System.Drawing.Point(49, 105);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(122, 28);
            this.lblSalBruto.TabIndex = 2;
            this.lblSalBruto.Text = "salário Bruto";
            // 
            // lblNumFilho
            // 
            this.lblNumFilho.AutoSize = true;
            this.lblNumFilho.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblNumFilho.Location = new System.Drawing.Point(44, 174);
            this.lblNumFilho.Name = "lblNumFilho";
            this.lblNumFilho.Size = new System.Drawing.Size(136, 28);
            this.lblNumFilho.TabIndex = 3;
            this.lblNumFilho.Text = "Número filhos";
            // 
            // lblDescIrpf
            // 
            this.lblDescIrpf.AutoSize = true;
            this.lblDescIrpf.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblDescIrpf.Location = new System.Drawing.Point(433, 458);
            this.lblDescIrpf.Name = "lblDescIrpf";
            this.lblDescIrpf.Size = new System.Drawing.Size(130, 28);
            this.lblDescIrpf.TabIndex = 4;
            this.lblDescIrpf.Text = "Desconto Irpf";
            // 
            // lblDescInss
            // 
            this.lblDescInss.AutoSize = true;
            this.lblDescInss.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblDescInss.Location = new System.Drawing.Point(431, 386);
            this.lblDescInss.Name = "lblDescInss";
            this.lblDescInss.Size = new System.Drawing.Size(132, 28);
            this.lblDescInss.TabIndex = 5;
            this.lblDescInss.Text = "Desconto Inss";
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSalLiquido.Location = new System.Drawing.Point(44, 610);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(166, 31);
            this.lblSalLiquido.TabIndex = 6;
            this.lblSalLiquido.Text = "Salário Liquido";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSalFamilia.Location = new System.Drawing.Point(44, 510);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(138, 28);
            this.lblSalFamilia.TabIndex = 7;
            this.lblSalFamilia.Text = "Salário Familia";
            // 
            // lblAliIfpf
            // 
            this.lblAliIfpf.AutoSize = true;
            this.lblAliIfpf.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblAliIfpf.Location = new System.Drawing.Point(38, 448);
            this.lblAliIfpf.Name = "lblAliIfpf";
            this.lblAliIfpf.Size = new System.Drawing.Size(127, 28);
            this.lblAliIfpf.TabIndex = 8;
            this.lblAliIfpf.Text = "Aliquiota Irpf";
            // 
            // lblAliInss
            // 
            this.lblAliInss.AutoSize = true;
            this.lblAliInss.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblAliInss.Location = new System.Drawing.Point(36, 392);
            this.lblAliInss.Name = "lblAliInss";
            this.lblAliInss.Size = new System.Drawing.Size(129, 28);
            this.lblAliInss.TabIndex = 9;
            this.lblAliInss.Text = "Aliquiota Inss";
            // 
            // lblMostra
            // 
            this.lblMostra.AutoSize = true;
            this.lblMostra.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblMostra.Location = new System.Drawing.Point(44, 334);
            this.lblMostra.Name = "lblMostra";
            this.lblMostra.Size = new System.Drawing.Size(0, 23);
            this.lblMostra.TabIndex = 10;
            // 
            // cbxCasado
            // 
            this.cbxCasado.AutoSize = true;
            this.cbxCasado.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbxCasado.Location = new System.Drawing.Point(654, 219);
            this.cbxCasado.Name = "cbxCasado";
            this.cbxCasado.Size = new System.Drawing.Size(98, 32);
            this.cbxCasado.TabIndex = 11;
            this.cbxCasado.Text = "Casado";
            this.cbxCasado.UseVisualStyleBackColor = true;
            // 
            // msbxSalBruto
            // 
            this.msbxSalBruto.Location = new System.Drawing.Point(265, 105);
            this.msbxSalBruto.Mask = "00000.00";
            this.msbxSalBruto.Name = "msbxSalBruto";
            this.msbxSalBruto.Size = new System.Drawing.Size(125, 27);
            this.msbxSalBruto.TabIndex = 12;
            // 
            // txtNomeFunc
            // 
            this.txtNomeFunc.Location = new System.Drawing.Point(265, 46);
            this.txtNomeFunc.Name = "txtNomeFunc";
            this.txtNomeFunc.Size = new System.Drawing.Size(125, 27);
            this.txtNomeFunc.TabIndex = 13;
            // 
            // msbxAliInss
            // 
            this.msbxAliInss.Enabled = false;
            this.msbxAliInss.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.msbxAliInss.Location = new System.Drawing.Point(217, 392);
            this.msbxAliInss.Name = "msbxAliInss";
            this.msbxAliInss.Size = new System.Drawing.Size(125, 34);
            this.msbxAliInss.TabIndex = 14;
            // 
            // msbxAliIrpf
            // 
            this.msbxAliIrpf.Enabled = false;
            this.msbxAliIrpf.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.msbxAliIrpf.Location = new System.Drawing.Point(217, 452);
            this.msbxAliIrpf.Name = "msbxAliIrpf";
            this.msbxAliIrpf.Size = new System.Drawing.Size(125, 34);
            this.msbxAliIrpf.TabIndex = 15;
            // 
            // msbxsalFami
            // 
            this.msbxsalFami.Enabled = false;
            this.msbxsalFami.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.msbxsalFami.Location = new System.Drawing.Point(217, 510);
            this.msbxsalFami.Name = "msbxsalFami";
            this.msbxsalFami.Size = new System.Drawing.Size(125, 34);
            this.msbxsalFami.TabIndex = 16;
            this.msbxsalFami.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.msbxsalFami_MaskInputRejected);
            // 
            // msbxSalLiqui
            // 
            this.msbxSalLiqui.Enabled = false;
            this.msbxSalLiqui.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.msbxSalLiqui.Location = new System.Drawing.Point(232, 610);
            this.msbxSalLiqui.Name = "msbxSalLiqui";
            this.msbxSalLiqui.Size = new System.Drawing.Size(125, 38);
            this.msbxSalLiqui.TabIndex = 17;
            // 
            // msbxDescIrpf
            // 
            this.msbxDescIrpf.Enabled = false;
            this.msbxDescIrpf.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.msbxDescIrpf.Location = new System.Drawing.Point(604, 452);
            this.msbxDescIrpf.Name = "msbxDescIrpf";
            this.msbxDescIrpf.Size = new System.Drawing.Size(125, 34);
            this.msbxDescIrpf.TabIndex = 19;
            // 
            // cbxFilho
            // 
            this.cbxFilho.AutoCompleteCustomSource.AddRange(new string[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.cbxFilho.FormattingEnabled = true;
            this.cbxFilho.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.cbxFilho.Location = new System.Drawing.Point(265, 174);
            this.cbxFilho.Name = "cbxFilho";
            this.cbxFilho.Size = new System.Drawing.Size(151, 28);
            this.cbxFilho.TabIndex = 20;
            // 
            // msbxdescInss
            // 
            this.msbxdescInss.Enabled = false;
            this.msbxdescInss.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.msbxdescInss.Location = new System.Drawing.Point(604, 386);
            this.msbxdescInss.Name = "msbxdescInss";
            this.msbxdescInss.Size = new System.Drawing.Size(125, 34);
            this.msbxdescInss.TabIndex = 21;
            // 
            // rbnFeminino
            // 
            this.rbnFeminino.AutoSize = true;
            this.rbnFeminino.Checked = true;
            this.rbnFeminino.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rbnFeminino.Location = new System.Drawing.Point(18, 26);
            this.rbnFeminino.Name = "rbnFeminino";
            this.rbnFeminino.Size = new System.Drawing.Size(43, 32);
            this.rbnFeminino.TabIndex = 22;
            this.rbnFeminino.TabStop = true;
            this.rbnFeminino.Text = "F";
            this.rbnFeminino.UseVisualStyleBackColor = true;
            // 
            // gbxSexo
            // 
            this.gbxSexo.Controls.Add(this.rbnMasculino);
            this.gbxSexo.Controls.Add(this.rbnFeminino);
            this.gbxSexo.Location = new System.Drawing.Point(558, 46);
            this.gbxSexo.Name = "gbxSexo";
            this.gbxSexo.Size = new System.Drawing.Size(250, 125);
            this.gbxSexo.TabIndex = 24;
            this.gbxSexo.TabStop = false;
            this.gbxSexo.Text = "Sexo";
            // 
            // rbnMasculino
            // 
            this.rbnMasculino.AutoSize = true;
            this.rbnMasculino.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rbnMasculino.Location = new System.Drawing.Point(18, 64);
            this.rbnMasculino.Name = "rbnMasculino";
            this.rbnMasculino.Size = new System.Drawing.Size(51, 32);
            this.rbnMasculino.TabIndex = 23;
            this.rbnMasculino.TabStop = true;
            this.rbnMasculino.Text = "M";
            this.rbnMasculino.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(891, 705);
            this.Controls.Add(this.gbxSexo);
            this.Controls.Add(this.msbxdescInss);
            this.Controls.Add(this.cbxFilho);
            this.Controls.Add(this.msbxDescIrpf);
            this.Controls.Add(this.msbxSalLiqui);
            this.Controls.Add(this.msbxsalFami);
            this.Controls.Add(this.msbxAliIrpf);
            this.Controls.Add(this.msbxAliInss);
            this.Controls.Add(this.txtNomeFunc);
            this.Controls.Add(this.msbxSalBruto);
            this.Controls.Add(this.cbxCasado);
            this.Controls.Add(this.lblMostra);
            this.Controls.Add(this.lblAliInss);
            this.Controls.Add(this.lblAliIfpf);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.lblDescInss);
            this.Controls.Add(this.lblDescIrpf);
            this.Controls.Add(this.lblNumFilho);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblNomeFunc);
            this.Controls.Add(this.brnVeriDesc);
            this.Name = "Form1";
            this.Text = "Form1";
            this.gbxSexo.ResumeLayout(false);
            this.gbxSexo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button brnVeriDesc;
        private Label lblNomeFunc;
        private Label lblSalBruto;
        private Label lblNumFilho;
        private Label lblDescIrpf;
        private Label lblDescInss;
        private Label lblSalLiquido;
        private Label lblSalFamilia;
        private Label lblAliIfpf;
        private Label lblAliInss;
        private Label lblMostra;
        private CheckBox cbxCasado;
        private MaskedTextBox msbxSalBruto;
        private TextBox txtNomeFunc;
        private MaskedTextBox msbxAliInss;
        private MaskedTextBox msbxAliIrpf;
        private MaskedTextBox msbxsalFami;
        private MaskedTextBox msbxSalLiqui;
        private MaskedTextBox msbxDescIrpf;
        private ComboBox cbxFilho;
        private MaskedTextBox msbxdescInss;
        private RadioButton rbnFeminino;
        private GroupBox gbxSexo;
        private RadioButton rbnMasculino;
    }
}